function activate(context) {
  console.log('Activating Vue Syntax Highlight plugin');

  // 注册 Vue 语言
  const languageRegistration = context.languages.register({
    language: {
      id: 'vue',
      extensions: ['.vue'],
      aliases: ['Vue', 'vue'],
      mimetypes: ['text/x-vue']
    },
    tokensProvider: {
      keywords: ['template', 'script', 'style', 'setup'],
      tokenizer: {
        root: [
          [/<template.*?>/, 'tag.template'],
          [/<\/template>/, 'tag.template'],
          [/<script.*?>/, 'tag.script'],
          [/<\/script>/, 'tag.script'],
          [/<style.*?>/, 'tag.style'],
          [/<\/style>/, 'tag.style'],
          [/<!--/, 'comment', '@comment'],
          [/\/\*/, 'comment', '@comment'],
          [/\/\//, 'comment', '@linecomment'],
          [/{{.*?}}/, 'string.interpolated'],
          [/<\/?[\w-]+/, 'tag'],
          [/[\w-]+(?=\s*=)/, 'attribute.name'],
          [/"[^"]*"/, 'string'],
          [/'[^']*'/, 'string'],
          [/\b(const|let|var|function|return|if|else|for|while|new|this|class|extends|import|from|export|default|setup)\b/, 'keyword'],
          [/\b(import|export|from|as)\b/, 'keyword'],
          [/[#.]?[\w-]+(?=\s*\{)/, 'selector'],
          [/[\w-]+(?=\s*:)/, 'property'],
          [/[:;{}<>]/, 'delimiter'],
          [/\b(px|em|rem|%|vh|vw)\b/, 'unit'],
          [/#[0-9a-fA-F]{3,8}\b/, 'number'],
          [/./, 'text']
        ],
        comment: [
          [/-->/, 'comment', '@pop'],
          [/\*\//, 'comment', '@pop'],
          [/./, 'comment']
        ],
        linecomment: [
          [/$/, 'comment', '@pop'],
          [/./, 'comment']
        ]
      }
    },
    themeRules: [
      { token: 'tag', foreground: '#569cd6' },
      { token: 'tag.template', foreground: '#4ec9b0' },
      { token: 'tag.script', foreground: '#ce9178' },
      { token: 'tag.style', foreground: '#d7ba7d' },
      { token: 'attribute.name', foreground: '#9cdcfe' },
      { token: 'string.interpolated', foreground: '#dcdcaa' },
      { token: 'keyword', foreground: '#569cd6' },
      { token: 'selector', foreground: '#d7ba7d' },
      { token: 'property', foreground: '#9cdcfe' },
      { token: 'unit', foreground: '#b5cea8' },
      { token: 'number', foreground: '#b5cea8' },
      { token: 'string', foreground: '#ce9178' },
      { token: 'comment', foreground: '#6a9955' },
      { token: 'delimiter', foreground: '#d4d4d4' }
    ]
  });

  context.subscriptions.push(languageRegistration);
  console.log('Vue Syntax Highlight plugin activated');
}

function deactivate() {
  console.log('Vue Syntax Highlight plugin deactivated');
}

module.exports = {
  activate,
  deactivate
};
