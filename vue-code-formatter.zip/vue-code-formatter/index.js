// Vue Code Formatter Plugin
// 所有格式化逻辑都在这里，IDE 不包含任何格式化代码

function activate(context) {
  console.log('Activating Vue Code Formatter plugin');
}

// 格式化 Vue 文件
function formatVueCode(code) {
  let formatted = code;
  
  try {
    // 1. 标准化换行符
    formatted = formatted.replace(/\r\n/g, '\n');
    
    // 2. 分别格式化各个区块
    formatted = formatVueTemplate(formatted);
    formatted = formatVueScript(formatted);
    formatted = formatVueStyle(formatted);
    
    // 3. 最终清理
    formatted = finalCleanup(formatted);
  } catch (e) {
    console.error('Vue formatting error:', e);
    return code;
  }
  
  return formatted;
}

// 格式化 Template 部分
function formatVueTemplate(code) {
  return code.replace(/(<template[\s\S]*?>)([\s\S]*?)(<\/template>)/gi, (match, openTag, content, closeTag) => {
    // 预处理：分离标签
    let processed = content
      .replace(/></g, '>\n<')
      .replace(/\n\s*\n/g, '\n');
    
    // 分割成行，修剪
    let lines = processed
      .split('\n')
      .map(line => line.trim())
      .filter(line => line);
    
    // 嵌套式缩进 2 个空格 - 重写逻辑
    const indentedLines = [];
    let indentLevel = 0;
    
    for (const line of lines) {
      // 先检查是否要减少缩进
      const isClosingTag = /^<\//.test(line);
      let currentIndent = indentLevel;
      
      if (isClosingTag) {
        currentIndent = Math.max(0, indentLevel - 1);
      }
      
      // 添加当前行
      const indent = '  '.repeat(currentIndent);
      indentedLines.push(indent + line);
      
      // 检查是否是开始标签
      const isOpeningTag = /^<[^\/!][^>]*>/.test(line);
      const isSelfClosing = /\/>/.test(line) || /^<[^\/!][^>]*\/>$/.test(line);
      const hasBothTags = /^<[^\/!][^>]*>.*<\/.*>/.test(line) && !isSelfClosing;
      
      // 增加缩进
      if (isOpeningTag && !isSelfClosing && !hasBothTags) {
        indentLevel++;
      }
      
      // 减少缩进
      if (isClosingTag) {
        indentLevel = Math.max(0, indentLevel - 1);
      }
    }
    
    const formattedContent = indentedLines.join('\n');
    return `${openTag}\n${formattedContent}\n${closeTag}`;
  });
}

// 格式化 Script 部分
function formatVueScript(code) {
  return code.replace(/(<script[\s\S]*?>)([\s\S]*?)(<\/script>)/gi, (match, openTag, content, closeTag) => {
    let formatted = content;
    
    // 常用规则 - 不处理任何注释！
    formatted = formatted
      .replace(/\}\s*else\s*\{/g, '} else {')
      .replace(/\)\s*\{/g, ') {')
      .replace(/;\s*}/g, '; }')
      .replace(/,\s*([a-zA-Z_$])/g, ', $1')
      .replace(/\}\s*catch\s*\(/g, '} catch (')
      .replace(/\}\s*finally\s*\{/g, '} finally {')
      .replace(/\}\s*else\s*if\s*\(/g, '} else if (')
      .replace(/\}\s*from\s*['"]/g, "} from '")
      .replace(/import\s*\(\s*/g, 'import(')
      .replace(/\)\s*\)/g, '))')
      .replace(/\s*=>\s*\{/g, ' => {')
      .replace(/\s*=>\s*/g, ' => ')
      .replace(/\s*:\s*/g, ': ')
      .replace(/\s*=\s*/g, ' = ')
      .replace(/\s*\+=\s*/g, ' += ')
      .replace(/\s*-=\s*/g, ' -= ')
      .replace(/\s*\+\s*/g, ' + ')
      .replace(/\s*-\s*/g, ' - ')
      .replace(/\s*\*\s*/g, ' * ')
      // 注意：不处理 / / 操作符，防止破坏注释
      .replace(/\s*===\s*/g, ' === ')
      .replace(/\s*!==\s*/g, ' !== ')
      .replace(/\s*&&\s*/g, ' && ')
      .replace(/\s*\|\|\s*/g, ' || ');
    
    // 处理导入语句
    formatted = formatted.replace(/import\s*\{([^}]+)\}\s*from/g, (match, imports) => {
      const formattedImports = imports.split(',').map(s => s.trim()).join(', ');
      return `import { ${formattedImports} } from`;
    });
    
    // 处理对象字面量
    formatted = formatted.replace(/\{([^}{]*)\}/g, (match, inside) => {
      if (!inside.includes('\n')) {
        const pairs = inside.split(',').map(s => s.trim()).filter(s => s);
        if (pairs.length > 0) {
          return `{ ${pairs.join(', ')} }`;
        }
      }
      return match;
    });
    
    // 清理行尾空格
    formatted = formatted
      .split('\n')
      .map(line => line.trimEnd())
      .join('\n');
    
    // 添加适当空行
    formatted = addProperEmptyLines(formatted);
    
    return `${openTag}\n${formatted}\n${closeTag}`;
  });
}

// 格式化 Style 部分
function formatVueStyle(code) {
  return code.replace(/(<style[\s\S]*?>)([\s\S]*?)(<\/style>)/gi, (match, openTag, content, closeTag) => {
    // 预处理
    let processed = content
      .replace(/\{/g, ' {\n')
      .replace(/\}/g, '\n}\n')
      .replace(/;([^\n])/g, ';\n$1')
      .replace(/\n\s*\n/g, '\n');
    
    let lines = processed
      .split('\n')
      .map(line => line.trim())
      .filter(line => line);
    
    // 缩进和格式化
    const indentedLines = [];
    let inBlock = false;
    
    for (const line of lines) {
      if (line.endsWith('{')) {
        // style 选择器和 { 之间加一个空格
        const selectorPart = line.slice(0, -1).trim();
        indentedLines.push(`${selectorPart} {`);
        inBlock = true;
      } else if (line === '}') {
        indentedLines.push(line);
        inBlock = false;
      } else if (inBlock) {
        indentedLines.push('  ' + line);
      } else {
        indentedLines.push(line);
      }
    }
    
    const formattedContent = indentedLines.join('\n');
    return `${openTag}\n${formattedContent}\n${closeTag}`;
  });
}

// 最终清理函数
function finalCleanup(code) {
  let lines = code.split('\n');
  
  // 2. 行尾去空格
  lines = lines.map(line => line.trimEnd());
  
  // 4. 不允许连续多个空行，最多保留1行空行
  const cleanedLines = [];
  let lastLineEmpty = false;
  
  for (const line of lines) {
    const isEmpty = !line.trim();
    
    if (isEmpty) {
      if (!lastLineEmpty) {
        cleanedLines.push(line);
      }
      lastLineEmpty = true;
    } else {
      cleanedLines.push(line);
      lastLineEmpty = false;
    }
  }
  
  // 3. 文件开头结尾无空行
  while (cleanedLines.length > 0 && !cleanedLines[0].trim()) {
    cleanedLines.shift();
  }
  while (cleanedLines.length > 0 && !cleanedLines[cleanedLines.length - 1].trim()) {
    cleanedLines.pop();
  }
  
  // 加上文件末尾一个换行
  return cleanedLines.join('\n') + '\n';
}

// 适当空行
function addProperEmptyLines(code) {
  const lines = code.split('\n');
  const result = [];
  let lastLine = '';
  let lastNonEmpty = '';
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    
    if (!trimmed) {
      if (lastLine.trim()) {
        result.push(line);
      }
      lastLine = line;
      continue;
    }
    
    let addEmpty = false;
    
    // import/export 块结束后加空行
    if (/^(import|export)\s/.test(lastNonEmpty) && !/^(import|export)\s/.test(trimmed)) {
      addEmpty = true;
    }
    
    // 关键字前加空行
    if (i > 0 && /^(const|let|var|function|class|if|for|while|switch|try|return)\s/.test(trimmed)) {
      if (!lastNonEmpty.endsWith('{') && 
          !lastNonEmpty.endsWith(',') &&
          !lastNonEmpty.endsWith(';') &&
          !/^(const|let|var)\s/.test(lastNonEmpty)) {
        addEmpty = true;
      }
    }
    
    // 块结束后加空行
    if (lastNonEmpty.trim() === '}' && !/^(else|catch|finally)\s/.test(trimmed)) {
      addEmpty = true;
    }
    
    if (addEmpty && lastLine.trim()) {
      result.push('');
    }
    
    result.push(line);
    lastLine = line;
    if (trimmed) {
      lastNonEmpty = trimmed;
    }
  }
  
  return result.join('\n');
}

// 格式化 JSON
function formatJSON(code) {
  try {
    return JSON.stringify(JSON.parse(code), null, 2);
  } catch {
    return code;
  }
}

function isVueFile(fileName) {
  return fileName && fileName.toLowerCase().endsWith('.vue');
}

function isJSONFile(fileName) {
  return fileName && fileName.toLowerCase().endsWith('.json');
}

function executeCommand(commandId, ...args) {
  if (commandId === 'vueCodeFormatter.format') {
    const [code, fileName] = args;
    
    if (isVueFile(fileName)) {
      console.log('Formatting Vue file:', fileName);
      return formatVueCode(code);
    } else if (isJSONFile(fileName)) {
      console.log('Formatting JSON file:', fileName);
      return formatJSON(code);
    }
    
    return undefined;
  }
  return undefined;
}

function deactivate() {
  console.log('Vue Code Formatter plugin deactivated');
}

module.exports = {
  activate,
  deactivate,
  executeCommand
};
