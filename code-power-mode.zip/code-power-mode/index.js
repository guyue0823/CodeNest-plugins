// Code Power Mode Plugin
// 所有特效逻辑都在这里，IDE 不包含任何特效代码

let isEnabled = true;

// 粒子颜色数组 - 浅蓝色系
const particleColors = [
  '#87CEEB', '#ADD8E6', '#B0E0E6', '#AFEEEE', '#87CEFA',
  '#00BFFF', '#1E90FF', '#6495ED', '#4169E1', '#00CED1'
];

function activate(context) {
  console.log('Activating Code Power Mode plugin');
  context.state = {
    isEnabled
  };
}

// 切换 Power Mode
function togglePowerMode() {
  isEnabled = !isEnabled;
  return {
    enabled: isEnabled,
    message: `Code Power Mode ${isEnabled ? 'enabled' : 'disabled'}!`
  };
}

// 获取粒子配置
function getParticleConfig() {
  return {
    enabled: isEnabled,
    colors: particleColors,
    minSize: 4,
    maxSize: 10,
    minCount: 5,
    maxCount: 10,
    minVelocity: 30,
    maxVelocity: 60,
    gravity: 1,
    opacityDecay: 0.02,
    scaleDecay: 0.01,
    startOffsetX: 20,
    startOffsetY: 20,
    minAngle: Math.PI * 0.25, // 45度
    maxAngle: Math.PI * 0.75  // 135度，主要向右和向下
  };
}

// 创建粒子数据（供 IDE 渲染用）
function createParticleData(x, y) {
  if (!isEnabled) return null;
  
  const config = getParticleConfig();
  const particles = [];
  
  const count = Math.floor(Math.random() * (config.maxCount - config.minCount + 1)) + config.minCount;
  
  for (let i = 0; i < count; i++) {
    const size = Math.random() * (config.maxSize - config.minSize) + config.minSize;
    const color = config.colors[Math.floor(Math.random() * config.colors.length)];
    const angle = Math.random() * (config.maxAngle - config.minAngle) + config.minAngle;
    const velocity = Math.random() * (config.maxVelocity - config.minVelocity) + config.minVelocity;
    
    const startX = x + Math.random() * config.startOffsetX;
    const startY = y + Math.random() * config.startOffsetY;
    
    particles.push({
      id: Date.now() + i + Math.random(),
      x: startX,
      y: startY,
      size,
      color,
      velocityX: Math.cos(angle) * velocity,
      velocityY: Math.sin(angle) * velocity,
      opacity: 1,
      scale: 1
    });
  }
  
  return {
    particles,
    config
  };
}

function executeCommand(commandId, ...args) {
  switch (commandId) {
    case 'codePowerMode.toggle':
      return togglePowerMode();
    case 'codePowerMode.isEnabled':
      return isEnabled;
    case 'codePowerMode.getConfig':
      return getParticleConfig();
    case 'codePowerMode.createParticles':
      const [x, y] = args;
      return createParticleData(x, y);
    default:
      return undefined;
  }
}

function deactivate() {
  console.log('Code Power Mode plugin deactivated');
}

module.exports = {
  activate,
  deactivate,
  executeCommand
};
